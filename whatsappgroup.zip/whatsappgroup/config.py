
CHROME_PROFILE_PATH = "user-data-dir=C:\\Users\\Nishith\\AppData\\Local\\Google\\Chrome\\User Data\\Wtsp"


# Windows 7, 8.1, and 10: C:\Users\<username>\AppData\Local\Google\Chrome\User Data\Default
# MAC OS X El Capitan: Users/<username>/Library/Application Support/Google/Chrome/Default
# Linux: /home/<username>/.config/google-chrome/default